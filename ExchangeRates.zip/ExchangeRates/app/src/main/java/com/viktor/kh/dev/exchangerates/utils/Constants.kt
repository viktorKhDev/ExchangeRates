package com.viktor.kh.dev.exchangerates.utils

  val DATE_FORMAT : String  = "dd-MM-yyyy"
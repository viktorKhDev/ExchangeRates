package com.viktor.kh.dev.exchangerates.di

import dagger.Module


@Module
class AdaptersModule {


}